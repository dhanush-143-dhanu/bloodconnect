/* =========================================================
   seed.js — first-run demo data so the app isn't empty
   Base location defaults to Bengaluru; if the visitor allows
   geolocation elsewhere the search still works globally.
   ========================================================= */

const SEED_BASE = { lat: 12.9716, lng: 77.5946 }; // Bengaluru

const FIRST_NAMES = ['Aarav','Vihaan','Ishaan','Kabir','Rohan','Aditi','Meera','Sana','Priya','Neha',
  'Karthik','Arjun','Divya','Sneha','Farhan','Zoya','Rahul','Ananya','Vikram','Pooja',
  'Sameer','Tanvi','Nikhil','Ritika','Yash'];
const LAST_NAMES = ['Sharma','Verma','Iyer','Nair','Reddy','Gupta','Khan','Menon','Rao','Kapoor',
  'Bose','Chatterjee','Pillai','Shetty','Joshi'];

function randomPhone() {
  return '+91 9' + Math.floor(100000000 + Math.random() * 899999999).toString().slice(0, 9);
}

function seedIfEmpty() {
  const existing = DB.getDonors();
  if (existing.length > 0) return;

  const donors = [];
  for (let i = 0; i < 34; i++) {
    const loc = Geo.randomPointNear(SEED_BASE, 14);
    const group = BLOOD_GROUPS[Math.floor(Math.random() * BLOOD_GROUPS.length)];
    const name = `${FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)]} ${LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)]}`;
    donors.push({
      id: 'D' + (1000 + i),
      name,
      bloodGroup: group,
      phone: randomPhone(),
      lat: loc.lat,
      lng: loc.lng,
      available: Math.random() > 0.28,
      donations: Math.floor(Math.random() * 12),
      createdAt: Date.now() - Math.floor(Math.random() * 1e10),
    });
  }
  DB.saveDonors(donors);
}
