/* =========================================================
   matching.js — real blood-type compatibility, not just
   exact-group matching. Donor group -> recipient groups
   they can safely give to.
   ========================================================= */

const BLOOD_GROUPS = ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'];

const CAN_DONATE_TO = {
  'O-':  ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'], // universal donor
  'O+':  ['O+', 'A+', 'B+', 'AB+'],
  'A-':  ['A-', 'A+', 'AB-', 'AB+'],
  'A+':  ['A+', 'AB+'],
  'B-':  ['B-', 'B+', 'AB-', 'AB+'],
  'B+':  ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+'],
  'AB+': ['AB+'], // universal recipient only receives from AB+ as a donor group here
};

const Matching = {
  isCompatible(donorGroup, recipientGroup) {
    return (CAN_DONATE_TO[donorGroup] || []).includes(recipientGroup);
  },
  /** groups whose donors CAN give to a given recipient group */
  compatibleDonorGroups(recipientGroup) {
    return BLOOD_GROUPS.filter(g => Matching.isCompatible(g, recipientGroup));
  },
  compatibilityScoreLabel(donorGroup, recipientGroup) {
    if (donorGroup === recipientGroup) return 'Exact match';
    if (donorGroup === 'O-') return 'Universal donor';
    return 'Compatible';
  },
};
