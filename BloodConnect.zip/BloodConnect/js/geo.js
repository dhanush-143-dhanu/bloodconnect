/* =========================================================
   geo.js — geolocation capture + distance math
   ========================================================= */

const Geo = {
  /** Returns a Promise<{lat,lng}> using the browser Geolocation API */
  locate(options = { enableHighAccuracy: true, timeout: 8000 }) {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser.'));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        err => reject(err),
        options
      );
    });
  },

  /** Haversine distance in km between two {lat,lng} points */
  distanceKm(a, b) {
    if (!a || !b) return Infinity;
    const R = 6371;
    const dLat = Geo._rad(b.lat - a.lat);
    const dLng = Geo._rad(b.lng - a.lng);
    const lat1 = Geo._rad(a.lat);
    const lat2 = Geo._rad(b.lat);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  },

  _rad(deg) { return (deg * Math.PI) / 180; },

  /** Random point within radiusKm of a center — used only to seed demo donors */
  randomPointNear(center, radiusKm) {
    const r = radiusKm * Math.sqrt(Math.random()) / 111; // ~111km per degree
    const theta = Math.random() * 2 * Math.PI;
    return { lat: center.lat + r * Math.cos(theta), lng: center.lng + r * Math.sin(theta) };
  },
};
