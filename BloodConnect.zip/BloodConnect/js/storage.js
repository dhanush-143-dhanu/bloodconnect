/* =========================================================
   storage.js — tiny localStorage "database"
   Keys:
     bc_donors     -> array of donor objects
     bc_requests   -> array of emergency request objects
     bc_session    -> id of the donor currently "logged in" (demo)
   This stands in for a real backend so the whole project runs
   as a static site (works on GitHub Pages, no server needed).
   ========================================================= */

const DB = {
  KEYS: { DONORS: 'bc_donors', REQUESTS: 'bc_requests', SESSION: 'bc_session' },

  _read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.error('DB read error', key, e);
      return fallback;
    }
  },
  _write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error('DB write error', key, e);
      return false;
    }
  },

  getDonors() { return this._read(this.KEYS.DONORS, []); },
  saveDonors(list) { return this._write(this.KEYS.DONORS, list); },
  addDonor(donor) {
    const list = this.getDonors();
    donor.id = donor.id || 'D' + Date.now().toString(36).toUpperCase();
    donor.createdAt = donor.createdAt || Date.now();
    donor.donations = donor.donations || 0;
    list.push(donor);
    this.saveDonors(list);
    return donor;
  },
  updateDonor(id, patch) {
    const list = this.getDonors();
    const idx = list.findIndex(d => d.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch };
    this.saveDonors(list);
    return list[idx];
  },
  getDonor(id) { return this.getDonors().find(d => d.id === id) || null; },

  getRequests() { return this._read(this.KEYS.REQUESTS, []); },
  saveRequests(list) { return this._write(this.KEYS.REQUESTS, list); },
  addRequest(req) {
    const list = this.getRequests();
    req.id = 'R' + Date.now().toString(36).toUpperCase();
    req.createdAt = Date.now();
    req.status = 'broadcasting';
    req.notifiedDonorIds = [];
    list.unshift(req);
    this.saveRequests(list);
    return req;
  },
  updateRequest(id, patch) {
    const list = this.getRequests();
    const idx = list.findIndex(r => r.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch };
    this.saveRequests(list);
    return list[idx];
  },

  getSession() { return localStorage.getItem(this.KEYS.SESSION); },
  setSession(donorId) { localStorage.setItem(this.KEYS.SESSION, donorId); },
  clearSession() { localStorage.removeItem(this.KEYS.SESSION); },
};
