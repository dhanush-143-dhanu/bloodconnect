/* =========================================================
   notify.js — in-app toasts + real browser Notification API
   Simulates the "SMS / email / in-app alert" burst described
   in the project brief, without needing a backend.
   ========================================================= */

const Notify = {
  ensureStack() {
    let stack = document.getElementById('toastStack');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'toastStack';
      document.body.appendChild(stack);
    }
    return stack;
  },

  toast(message, type = 'info', ms = 4200) {
    const stack = this.ensureStack();
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = `<span>${message}</span>`;
    stack.appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity .3s ease';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 300);
    }, ms);
  },

  async requestPermission() {
    if (!('Notification' in window)) return 'unsupported';
    if (Notification.permission === 'granted') return 'granted';
    if (Notification.permission === 'denied') return 'denied';
    return Notification.requestPermission();
  },

  async browserNotify(title, body) {
    const perm = await this.requestPermission();
    if (perm === 'granted') {
      try { new Notification(title, { body, icon: '' }); } catch (e) { /* no-op */ }
    }
  },
};
